
import View.StarterView;

import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) throws InterruptedException, FileNotFoundException {
        // VITOR SE QUISERES O TEXTO MAIS RAPIDO VAI Á CLASS IMPRESSORA E MUDA OS MILISEGUNDOS!
        StarterView.starterMenu();
    }
}
