package Domain.Items;

public abstract class Consumivel extends ItemHeroi{

    public Consumivel(String tipo, String nome, int preco, String era) {
        super(tipo, nome, preco, era);
    }
}
