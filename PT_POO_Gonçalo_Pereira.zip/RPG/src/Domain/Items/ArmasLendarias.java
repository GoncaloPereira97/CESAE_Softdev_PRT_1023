package Domain.Items;

public class ArmasLendarias extends Armas{
    public ArmasLendarias(String tipo, String nome, int preco, String era, int ataque, int ataqueEspecial, int vida, int primaryStat) {
        super(tipo, nome, preco, era, ataque, ataqueEspecial, vida, primaryStat);
    }
}
