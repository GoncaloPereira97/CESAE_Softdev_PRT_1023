import View.ClienteView;
import View.EntryView;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        EntryView.menuLogin();
    }
}
